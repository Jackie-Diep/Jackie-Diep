/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author tripl
 */
public abstract class Employee extends Person
{
    private int office;
    private double salary;
    private String dateHired;
    public Employee(String name, String address, String phoneNumber, String emailAddress, int office, double salary, String dateHired)
    {
        super(name, address, phoneNumber, emailAddress);
        this.office = office;
        this.salary = salary;
        this.dateHired = dateHired;
    }
    
    public void setOffice(int office)
    {
        this.office = office;
    }
    
    public int getOffice()
    {
        return this.office;
    }
    
    public void setSalary(double salary)
    {
        this.salary = salary;
    }
    
    public double getSalary()
    {
        return this.salary;
    }
    
    public void setDateHired(String dateHired)
    {
        this.dateHired = dateHired;
    }
    
    public String getDateHired()
    {
        return this.dateHired;
    }
}
