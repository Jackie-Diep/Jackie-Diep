/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author tripl
 */
public class Student extends Person
{
    public final class Status
    {
    private static final String freshman = "Freshman";
    private static final String sophomore = "Sophomore";
    private static final String junior = "Junior";
    private static final String senior = "Senior";
    
    public String getFreshman()
        {
            return freshman;
        }
     
    public String getSophomore()
        {
            return sophomore;
        }
     
    public String getJunior()
        {
            return junior;
        }

    public String getSenior()
        {
            return senior;
        }
    }   
    
    Status status = new Status();
    private String studentStatus;
    public Student(String name, String address, String phoneNumber, String emailAddress, int statusChosen)
    {
        super(name, address, phoneNumber, emailAddress);
        switch(statusChosen)
        {
            case 1: 
                studentStatus = status.getFreshman();
            break;
            case 2:
                studentStatus = status.getSophomore();
            break;
            case 3:
                studentStatus = status.getJunior();
            break;
            case 4:
                studentStatus = status.getSenior();
            break;
            default:
                studentStatus = "Unenrolled";
                System.out.println("Student: Unenrolled, please select 1 - 4");
                System.out.println("1. Freshman");
                System.out.println("2. Sophomore");      
                System.out.println("3. Junior");
                System.out.println("4. Senior");
        }
    }
    
    public void setStudentStatus(int statusChosen)
    {
        switch(statusChosen)
        {
            case 1: 
                studentStatus = status.getFreshman();
            break;
            case 2:
                studentStatus = status.getSophomore();
            break;
            case 3:
                studentStatus = status.getJunior();
            break;
            case 4:
                studentStatus = status.getSenior();
            break;
            default:
                System.out.println("Invalid class, please select 1 - 4");
                System.out.println("1. Freshman");
                System.out.println("2. Sophomore");      
                System.out.println("3. Junior");
                System.out.println("4. Senior");
        }
    }
    
    public String getStudentStatus()
    {
        return studentStatus;
    }
    
    @Override
    public void display()
    {
        System.out.printf("Status: %s%n", getStudentStatus());
        System.out.printf("Address: %s%n", getAddress());
        System.out.printf("Phone Number: %s%n", getPhoneNumber());
        System.out.printf("Email Address: %s%n", getEmailAddress());
    }
    
    @Override
    public String toString()
    {
        System.out.println("Student");
        return getName();
    }
}
