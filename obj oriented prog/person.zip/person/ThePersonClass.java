
package person;



public class ThePersonClass {

    //Person -> Student
    //Person -> Employee
        //Employee -> Faculty
        //Employee -> Staff
    //Person: Name, Address, Phone number, Email address
    //Student: Class(Freshman,Sophomore,Junior,Senior) as constants
    //Employee: Office, Salary, Date hired
    //Faculty: Office hours, Rank
    //Staff: Title
    //Also define a class MyDate: year, month, day
    //Override toString method in each class to display class name and person's name
    
    public static void main(String[] args) {
        MyDate dates[] = new MyDate[2];
        dates[0] = new MyDate(3, 15, 2005);
        dates[1] = new MyDate(9, 5, 2015);
        Student student = new Student("Phil", "999 Java Place", "228-999-9999", "JavaPlace1@Gmail.com", 1);
        Faculty faculty = new Faculty("Steven", "888 Java Place", "228-888-8888", "JavaPlace2@Gmail.com", 1, 60000, dates[0].toString(), "5:00pm - 9:00pm", "Professor");
        Staff staff = new Staff("John", "777 Java Place", "227-777-7777", "JavaPlace3@Gmail.com", 2, 30000, dates[1].toString(), "Custodian");
        System.out.println(student.toString());
        student.display();
        System.out.println();
        System.out.println(faculty.toString());
        faculty.display();
        System.out.println();
        System.out.println(staff.toString());
        staff.display();
        System.out.println();
    }
    
}
