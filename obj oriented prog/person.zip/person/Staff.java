/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author tripl
 */
public class Staff extends Employee
{
    private String title;
    public Staff(String name, String address, String phoneNumber, String emailAddress, int office, double salary, String dateHired, String title)
    {
        super(name, address, phoneNumber, emailAddress, office, salary, dateHired);
        this.title = title;
    }
    
    public void setTitle(String title)
    {
        this.title = title;
    }
    
    public String getTitle()
    {
        return this.title;
    }
    
    @Override
    public void display()
    {
        System.out.printf("Title: %s%n", getTitle());
        System.out.printf("Office Number: %d%n", getOffice());
        System.out.printf("Salary: $%.2f%n", getSalary());
        System.out.printf("Date Hired: %s%n", getDateHired());
        System.out.printf("Address: %s%n", getAddress());
        System.out.printf("Phone Number: %s%n", getPhoneNumber());
        System.out.printf("Email Address: %s%n", getEmailAddress());
    }
    
    @Override
    public String toString()
    {
        System.out.println("Staff");
        return getName();
    }
}
