/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author tripl
 */
public class MyDate
    {
        private int year;
        private int month;
        private int day;
        
        public MyDate(int month, int day, int year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }
        
        public String toString()
        {
            return month+"/"+day+"/"+year;
        }
        
        public void setYear(int year)
        {
            this.year = year;
        }
        
        public int getYear()
        {
            return this.year;
        }
        
        public void setDay(int day)
        {
            this.day = day;
        }
        
        public int getDay()
        {
            return this.day;
        }
        
        public void setMonth(int month)
        {
            this.month = month;
        }
        
        public int getMonth()
        {
            return this.month;
        }
    }
